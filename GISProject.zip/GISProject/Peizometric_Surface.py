import arcpy

folder_path= r'C:\\Users\\Grady\\Desktop\\GISProject\\GISProject'
gdb_name='Peizometric_Surface.gdb'
gdb_path=folder_path + '\\' + gdb_name
arcpy.CreateFileGDB_management(folder_path,gdb_name)

#plots xy data from csv
arcpy.management.XYTableToPoint(r"C:\\Users\\Grady\Desktop\\GISProject\\Aquifer_Data\\Trinity_data.csv", 
r"C:\\Users\\Grady\\Desktop\\GISProject\\GISProject\\Peizometric_Surface.gdb\\Trinity_data_XY", 
"LongitudeDD",
 "LatitudeDD", 
 None, 
 'GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137.0,298.257223563]],PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]];-400 -400 1000000000;-100000 10000;-100000 10000;8.98315284119521E-09;0.001;0.001;IsHighPrecision')

arcpy.ddd.TopoToRaster("'Trinity_data_XY' WaterElevation PointElevation", r"C:\\Users\\Grady\\Desktop\\GISProject\\GISProject\\Peizometric_Surface.gdb\\Peizometric_surface", 
0.00451911080000014, 
'-98.631111 29.636945 -97.5013332999999 33.2202778000001 GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137.0,298.257223563]],PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]', 
20, None, None, "ENFORCE", "CONTOUR", 20, None, 1, 0, 2.5, 100, None, None, None, None, None, None, None, None)

arcpy.ddd.Contour("Peizometric_surface",
 r"C:\\Users\\Grady\\Desktop\\GISProject\\GISProject\\Peizometric_Surface.gdb\\Contours",
  10, 0, 1, "CONTOUR", None)