import pandas as pd

data = pd.read_csv('WaterLevelsByAquifer.csv')
df = data.drop_duplicates(subset='StateWellNumber',keep='last')

# Save the filtered DataFrame to a new CSV file named after aquifer
df.to_csv('HMB_data.csv', index=False)
